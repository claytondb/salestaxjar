<?php
/**
 * Sails Tax Blocks Integration
 *
 * Provides compatibility with WooCommerce Block Checkout.
 *
 * @package Sails_Tax
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;
use Automattic\WooCommerce\StoreApi\Schemas\V1\CartSchema;

/**
 * Blocks Integration class
 */
class Sails_Tax_Blocks_Integration implements IntegrationInterface {

    /**
     * The name of the integration.
     *
     * @return string
     */
    public function get_name() {
        return 'sails-tax';
    }

    /**
     * When called invokes any initialization/setup for the integration.
     */
    public function initialize() {
        // Only initialize if enabled
        if (get_option('sails_tax_enabled', 'no') !== 'yes') {
            return;
        }
        
        if (empty(get_option('sails_tax_api_key', ''))) {
            return;
        }
        
        // Hook into Store API cart updates
        add_action('woocommerce_store_api_cart_update_customer_from_request', array($this, 'update_customer_tax'), 10, 2);
        
        // Hook into order creation from Store API
        add_action('woocommerce_store_api_checkout_update_order_from_request', array($this, 'update_order_tax'), 10, 2);
        
        // Force tax recalculation when address changes
        add_filter('woocommerce_store_api_cart_select_shipping_rate', array($this, 'on_shipping_rate_selected'), 10, 2);
        
        // Extend cart schema to include tax info
        $this->extend_store_api();
    }

    /**
     * Returns an array of script handles to enqueue in the frontend context.
     *
     * @return string[]
     */
    public function get_script_handles() {
        return array();
    }

    /**
     * Returns an array of script handles to enqueue in the editor context.
     *
     * @return string[]
     */
    public function get_editor_script_handles() {
        return array();
    }

    /**
     * An array of key, value pairs of data made available to the block on the client side.
     *
     * @return array
     */
    public function get_script_data() {
        return array(
            'enabled' => get_option('sails_tax_enabled', 'no') === 'yes',
        );
    }

    /**
     * Extend Store API with Sails Tax data
     */
    private function extend_store_api() {
        if (!function_exists('woocommerce_store_api_register_endpoint_data')) {
            return;
        }
        
        woocommerce_store_api_register_endpoint_data(
            array(
                'endpoint'        => CartSchema::IDENTIFIER,
                'namespace'       => 'sails-tax',
                'data_callback'   => array($this, 'get_cart_tax_data'),
                'schema_callback' => array($this, 'get_cart_tax_schema'),
                'schema_type'     => ARRAY_A,
            )
        );
    }

    /**
     * Get cart tax data for Store API
     *
     * @return array
     */
    public function get_cart_tax_data() {
        $rate = WC()->session ? WC()->session->get('sails_tax_rate') : null;
        $amount = WC()->session ? WC()->session->get('sails_tax_amount') : null;
        
        return array(
            'rate'   => $rate,
            'amount' => $amount,
            'source' => 'sails-tax',
        );
    }

    /**
     * Get cart tax schema for Store API
     *
     * @return array
     */
    public function get_cart_tax_schema() {
        return array(
            'rate'   => array(
                'description' => 'Tax rate as decimal',
                'type'        => 'number',
                'context'     => array('view', 'edit'),
                'readonly'    => true,
            ),
            'amount' => array(
                'description' => 'Tax amount in currency',
                'type'        => 'number',
                'context'     => array('view', 'edit'),
                'readonly'    => true,
            ),
            'source' => array(
                'description' => 'Tax calculation source',
                'type'        => 'string',
                'context'     => array('view', 'edit'),
                'readonly'    => true,
            ),
        );
    }

    /**
     * Update customer tax when address changes via Store API
     *
     * @param WC_Customer $customer Customer object
     * @param WP_REST_Request $request Request object
     */
    public function update_customer_tax($customer, $request) {
        // Get address from request
        $billing = $request->get_param('billing_address');
        $shipping = $request->get_param('shipping_address');
        
        // Use shipping if available, otherwise billing
        $address = !empty($shipping['state']) ? $shipping : $billing;
        
        if (empty($address) || empty($address['country']) || $address['country'] !== 'US') {
            return;
        }
        
        $to_state = isset($address['state']) ? $address['state'] : '';
        $to_zip = isset($address['postcode']) ? $address['postcode'] : '';
        $to_city = isset($address['city']) ? $address['city'] : '';
        
        if (empty($to_state)) {
            return;
        }
        
        // Calculate tax via Sails API
        $this->calculate_and_store_tax($to_state, $to_zip, $to_city);
        
        // Force cart to recalculate
        WC()->cart->calculate_totals();
    }

    /**
     * When shipping rate is selected, recalculate tax
     *
     * @param string $rate_id Selected rate ID
     * @param array $options Options
     */
    public function on_shipping_rate_selected($rate_id, $options) {
        // Get customer shipping address
        $customer = WC()->customer;
        if (!$customer) {
            return $rate_id;
        }
        
        $to_state = $customer->get_shipping_state();
        $to_zip = $customer->get_shipping_postcode();
        $to_city = $customer->get_shipping_city();
        $to_country = $customer->get_shipping_country();
        
        if ($to_country !== 'US' || empty($to_state)) {
            return $rate_id;
        }
        
        // Recalculate with new shipping
        $this->calculate_and_store_tax($to_state, $to_zip, $to_city);
        
        return $rate_id;
    }

    /**
     * Update order tax during Store API checkout
     *
     * @param WC_Order $order Order object
     * @param WP_REST_Request $request Request object
     */
    public function update_order_tax($order, $request) {
        $to_state = $order->get_shipping_state();
        $to_zip = $order->get_shipping_postcode();
        $to_city = $order->get_shipping_city();
        $to_country = $order->get_shipping_country();
        
        // Fall back to billing if no shipping
        if (empty($to_state)) {
            $to_state = $order->get_billing_state();
            $to_zip = $order->get_billing_postcode();
            $to_city = $order->get_billing_city();
            $to_country = $order->get_billing_country();
        }
        
        // Only calculate for US addresses
        if ($to_country !== 'US' || empty($to_state)) {
            return;
        }
        
        // Calculate order subtotal
        $subtotal = 0;
        $line_items = array();
        
        foreach ($order->get_items() as $item) {
            $subtotal += floatval($item->get_subtotal());
            $product = $item->get_product();
            
            if ($product) {
                $line_items[] = array(
                    'id' => $item->get_id(),
                    'quantity' => $item->get_quantity(),
                    'unit_price' => floatval($item->get_subtotal()) / max(1, $item->get_quantity()),
                    'product_tax_code' => $this->map_tax_class_to_code($product->get_tax_class()),
                );
            }
        }
        
        $shipping = floatval($order->get_shipping_total());
        
        // Build API request
        $args = array(
            'amount' => $subtotal,
            'shipping' => $shipping,
            'to_state' => $to_state,
            'to_zip' => $to_zip,
            'to_city' => $to_city,
            'to_country' => $to_country,
            'line_items' => $line_items,
        );
        
        // Add from address if configured
        $from_state = get_option('sails_tax_from_state', '');
        if (!empty($from_state)) {
            $args['from_state'] = $from_state;
            $args['from_zip'] = get_option('sails_tax_from_zip', '');
            $args['from_city'] = get_option('sails_tax_from_city', '');
        }
        
        // Call API
        $result = Sails_Tax_API::calculate_tax($args);
        
        if (is_wp_error($result) || !isset($result['tax']['amount_to_collect'])) {
            Sails_Tax_API::log('Block checkout order tax failed: ' . (is_wp_error($result) ? $result->get_error_message() : 'Invalid response'));
            return;
        }
        
        // Apply tax to order
        $tax_amount = floatval($result['tax']['amount_to_collect']);
        $rate_label = sprintf('%s Sales Tax', $to_state);
        
        // Remove existing taxes
        $order->remove_order_items('tax');
        
        // Add new tax
        $item = new WC_Order_Item_Tax();
        $item->set_rate_id(999999999);
        $item->set_label($rate_label);
        $item->set_tax_total($tax_amount);
        $item->set_shipping_tax_total(0);
        $item->set_rate_percent(floatval($result['tax']['rate']) * 100);
        
        $order->add_item($item);
        $order->set_cart_tax($tax_amount);
        $order->calculate_totals(false);
        
        Sails_Tax_API::log('Block checkout order tax applied: ' . $tax_amount);
    }

    /**
     * Calculate tax and store in session
     *
     * @param string $to_state State code
     * @param string $to_zip ZIP code
     * @param string $to_city City name
     */
    private function calculate_and_store_tax($to_state, $to_zip, $to_city) {
        $cart = WC()->cart;
        if (!$cart) {
            return;
        }
        
        // Check cache first
        $cache_key = 'sails_tax_' . md5($to_state . $to_zip . $to_city . $cart->get_cart_hash());
        $cached = get_transient($cache_key);
        
        if ($cached !== false) {
            WC()->session->set('sails_tax_rate', $cached['rate']);
            WC()->session->set('sails_tax_amount', $cached['amount']);
            Sails_Tax_API::log('Using cached tax for block checkout: ' . $cached['amount']);
            return;
        }
        
        // Calculate cart totals
        $subtotal = 0;
        $line_items = array();
        
        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            $product = $cart_item['data'];
            $quantity = $cart_item['quantity'];
            $price = $product->get_price();
            $line_total = $price * $quantity;
            $subtotal += $line_total;
            
            $line_items[] = array(
                'id' => $cart_item_key,
                'quantity' => $quantity,
                'unit_price' => floatval($price),
                'product_tax_code' => $this->map_tax_class_to_code($product->get_tax_class()),
            );
        }
        
        $shipping = floatval($cart->get_shipping_total());
        
        // Build API request
        $args = array(
            'amount' => $subtotal,
            'shipping' => $shipping,
            'to_state' => $to_state,
            'to_zip' => $to_zip,
            'to_city' => $to_city,
            'to_country' => 'US',
            'line_items' => $line_items,
        );
        
        // Add from address if configured
        $from_state = get_option('sails_tax_from_state', '');
        if (!empty($from_state)) {
            $args['from_state'] = $from_state;
            $args['from_zip'] = get_option('sails_tax_from_zip', '');
            $args['from_city'] = get_option('sails_tax_from_city', '');
        }
        
        // Call API
        $result = Sails_Tax_API::calculate_tax($args);
        
        if (is_wp_error($result)) {
            Sails_Tax_API::log('Block checkout tax calculation failed: ' . $result->get_error_message());
            return;
        }
        
        if (!isset($result['tax']['amount_to_collect'])) {
            Sails_Tax_API::log('Block checkout invalid API response: ' . wp_json_encode($result));
            return;
        }
        
        $rate = floatval($result['tax']['rate']);
        $amount = floatval($result['tax']['amount_to_collect']);
        
        // Store in session
        WC()->session->set('sails_tax_rate', $rate);
        WC()->session->set('sails_tax_amount', $amount);
        
        // Cache for 5 minutes
        set_transient($cache_key, array('rate' => $rate, 'amount' => $amount), 5 * MINUTE_IN_SECONDS);
        
        Sails_Tax_API::log('Block checkout tax calculated: rate=' . $rate . ', amount=' . $amount);
    }

    /**
     * Map WooCommerce tax class to Sails Tax product tax code
     *
     * @param string $tax_class WooCommerce tax class
     * @return string|null Product tax code
     */
    private function map_tax_class_to_code($tax_class) {
        if (preg_match('/\-\s*(\d+)$/', $tax_class, $matches)) {
            return $matches[1];
        }
        
        $mappings = array(
            'clothing' => '20010',
            'food' => '40030',
            'grocery' => '40030',
            'digital' => '31000',
            'software' => '30070',
        );
        
        $tax_class_lower = strtolower($tax_class);
        if (isset($mappings[$tax_class_lower])) {
            return $mappings[$tax_class_lower];
        }
        
        return null;
    }
}
