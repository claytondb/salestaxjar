﻿<?php

if (!defined('ABSPATH')) exit;

class Sails_Tax_Checkout {
  // Cache key prefix for transient storage
  const CACHE_PREFIX = 'sails_tax_';
  const CACHE_TTL = 300; // 5 minutes

  public function register() {
    add_action('woocommerce_cart_calculate_fees', [$this, 'apply_estimated_tax'], 20, 1);
    add_action('woocommerce_review_order_before_order_total', [$this, 'maybe_render_customer_note']);
    // Store tax metadata on order completion
    add_action('woocommerce_checkout_order_processed', [$this, 'store_order_meta'], 10, 3);
    add_action('woocommerce_store_api_checkout_order_processed', [$this, 'store_order_meta_block'], 10, 1);
  }

  public function apply_estimated_tax($cart) {
    if (is_admin() && !defined('DOING_AJAX')) return;

    $opts = Sails_Tax_Settings::get();
    if (($opts['enabled'] ?? 'no') !== 'yes') return;

    // Get destination info from customer
    $customer = WC()->customer;
    if (!$customer) return;

    // Prefer shipping address, but fall back to billing (Block Checkout often only provides billing).
    $toZip = $customer->get_shipping_postcode();
    $toState = $customer->get_shipping_state();

    if (!$toZip) {
      $toZip = $customer->get_billing_postcode();
    }
    if (!$toState) {
      $toState = $customer->get_billing_state();
    }

    if (!$toZip || !$toState) {
      return; // wait until address is present
    }

    // Calculate taxable amount (subtotal + shipping). MVP: treat everything taxable.
    $amount = floatval($cart->get_subtotal() + $cart->get_shipping_total());
    if ($amount <= 0) return;

    // Check cache first to avoid redundant API calls
    $cache_key = $this->get_cache_key($amount, $toZip, $toState);
    $cached = get_transient($cache_key);
    
    if ($cached !== false) {
      $this->apply_tax_result($cart, $cached);
      return;
    }

    $api = new Sails_Tax_API();
    $result = $api->calculate($amount, $toZip, $toState);

    if (is_wp_error($result)) {
      // Merchant-visible note in checkout (admin only) and order note later.
      $cart->add_fee('Sales Tax (Sails)', 0, false);
      $this->store_last_notice([
        'confidence' => 'error',
        'message' => $result->get_error_message(),
        'amount' => $amount,
        'toZip' => $toZip,
        'toState' => $toState,
      ]);
      return;
    }

    // Cache successful result
    set_transient($cache_key, $result, self::CACHE_TTL);
    $this->apply_tax_result($cart, $result);
  }

  private function apply_tax_result($cart, $result) {
    $taxAmount = isset($result['taxAmount']) ? floatval($result['taxAmount']) : 0;
    $confidence = $result['confidence'] ?? 'state_only';
    $message = $result['message'] ?? '';
    $rate = $result['rate'] ?? null;

    // Add tax as a fee line item.
    $cart->add_fee('Sales Tax', $taxAmount, false);

    // Store disclaimer for rendering and for order meta.
    $this->store_last_notice([
      'confidence' => $confidence,
      'message' => $message,
      'taxAmount' => $taxAmount,
      'rate' => $rate,
    ]);
  }

  private function get_cache_key($amount, $zip, $state) {
    // Round amount to avoid cache misses on tiny price changes
    $rounded = round($amount, 2);
    return self::CACHE_PREFIX . md5($rounded . '|' . $zip . '|' . $state);
  }

  private function store_last_notice($data) {
    // Store in WC session for checkout display.
    if (WC()->session) {
      WC()->session->set('sails_tax_last', $data);
    }
  }

  public function maybe_render_customer_note() {
    $opts = Sails_Tax_Settings::get();
    if (($opts['customer_disclaimer'] ?? 'no') !== 'yes') return;

    $data = WC()->session ? WC()->session->get('sails_tax_last') : null;
    if (!$data || empty($data['message'])) return;

    $confidence = $data['confidence'] ?? '';
    if ($confidence === 'exact_zip') return; // only show when not exact

    echo '<tr class="sails-tax-estimate-note"><td colspan="2">';
    echo '<small style="color:#6b7280;">' . esc_html($data['message']) . '</small>';
    echo '</td></tr>';
  }

  /**
   * Store tax calculation metadata on order (classic checkout)
   */
  public function store_order_meta($order_id, $posted_data, $order) {
    $this->save_tax_meta_to_order($order);
  }

  /**
   * Store tax calculation metadata on order (block checkout)
   */
  public function store_order_meta_block($order) {
    $this->save_tax_meta_to_order($order);
  }

  private function save_tax_meta_to_order($order) {
    if (!$order) return;

    $data = WC()->session ? WC()->session->get('sails_tax_last') : null;
    if (!$data) return;

    // Store confidence level for reporting/auditing
    $order->update_meta_data('_sails_tax_confidence', $data['confidence'] ?? 'unknown');
    
    if (isset($data['taxAmount'])) {
      $order->update_meta_data('_sails_tax_amount', $data['taxAmount']);
    }
    if (isset($data['rate'])) {
      $order->update_meta_data('_sails_tax_rate', $data['rate']);
    }
    if (!empty($data['message'])) {
      $order->update_meta_data('_sails_tax_message', $data['message']);
    }

    $order->save();

    // Add order note for admin visibility
    $confidence = $data['confidence'] ?? 'unknown';
    if ($confidence !== 'exact_zip') {
      $note = sprintf(
        'Sails Tax: %s confidence. %s',
        ucfirst(str_replace('_', ' ', $confidence)),
        $data['message'] ?? ''
      );
      $order->add_order_note($note, false);
    }
  }
}
